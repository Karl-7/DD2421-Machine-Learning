import numpy, random, math
from scipy.optimize import minimize
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt


def minimization(objective,data,bounds,constraints,kernel):
    start=numpy.zeros(len(data.targets))
    def obj_wrapper(alpha):
        data.alpha=alpha
        return objective(data,kernel)
    ret=minimize(obj_wrapper, start, bounds=bounds, constraints=constraints)
    data.alpha=ret['x']
    return data.alpha
def objective(data,kernel):
        P=numpy.zeros((len(data.targets),len(data.targets)))
        sum=0
        for i in range(len(data.targets)):
            for j in range(len(data.targets)):
                P[i,j]=(data.targets[i]*data.targets[j]*kernel(data.data[i],data.data[j]))
                sum+=data.alpha[i]*data.alpha[j]*P[i,j]
        return 0.5*sum-numpy.sum(data.alpha)     
def zerofun(alpha,data):
    # Implement the function zerofun
    return numpy.dot(alpha,data.targets)

def generate_data(data_size):
    class data_class:
        def __init__(self):
            self.data=[]
            self.targets=[]
            self.alpha=[]
        def __iter__(self):
            return iter(self.data)
    dataset = data_class()

    # 生成数据
    dataset.data = numpy.concatenate((
        numpy.random.randn(int(data_size / 4), 2) * 0.5 + [2.0, 1.0],
        numpy.random.randn(int(data_size / 4), 2) * 0.5 + [-2.0, 1.0],
        numpy.random.randn(int(data_size / 2), 2) * 0.5 + [2.0, 2.0],
    ))

    # 生成目标值
    dataset.targets = numpy.concatenate((
        numpy.ones(int(data_size / 2)),
        numpy.ones(int(data_size / 2)) * -1
    ))
    dataset.alpha=numpy.zeros(data_size)
    # dataset=[]
    # dataset.data=numpy.concatenate((numpy.random.randn(int(data_size/4),2)*0.5+[2.0,1.0],
    #                         numpy.random.randn(int(data_size/4),2)*0.5+[-2.0,1.0],
    #                         numpy.random.randn(int(data_size/2),2)*0.5+[2.0,2.0],))
    # dataset.targets=numpy.concatenate((numpy.ones(int(data_size/2)),
    #                                    numpy.ones(int(data_size/2))*-1))
    permute=list(range(data_size))
    random.shuffle(permute)
    return dataset

def indicator(x, y, b):
    result = 0
    for sv in support_vectors:
        result += sv[-1] * sv[-2] * kernel([sv[0],sv[1]], [x, y])
    return result - b

def zerofun(alpha):
    return numpy.dot(alpha,data.targets)
def plot_data(data,support_vectors,b):
    for i in range(len(data.data)):
        if data.targets[i]==1:
            plt.plot(data.data[i][0],data.data[i][1],'r+')
        else:
            plt.plot(data.data[i][0],data.data[i][1],'b+')
    for sv in support_vectors:
        plt.plot(sv.data[0],sv.data[1],'go')
    xgrid=numpy.linspace(-5,5)
    ygrid=numpy.linspace(-4,4)
    grid=numpy.array([[indicator(x,y,b) for x in xgrid] for y in ygrid])
    plt.contour(xgrid,ygrid,grid,
                (-1.0,0.0,1.0),
                colors=('red','black','blue'),
                linewidths=(1,3,1))
    plt.axis('equal')
    plt.savefig('svmplot.pdf')
    plt.show()

def radial_basis_kernel(x,y):
    sigma=1
    return numpy.exp(-numpy.linalg.norm(numpy.subtract(x,y))**2/1*sigma**2)
if __name__=='__main__':
    numpy.random.seed(2019)
    data_size=40
    data=generate_data(data_size)
    C=2
    kernel=radial_basis_kernel
    margin_bounds=[(0,C) for b in range(data_size)]
    constrains=({'type':'eq','fun':zerofun})
    support_vectors=[]
    threshold=1e-5
    correct_prediction=0
    
    data.alpha=minimization(objective,data,margin_bounds,constrains,kernel)

    for i in range(len(data.alpha)):
        if data.alpha[i] > threshold:
            support_vectors.append(numpy.hstack((data.data[i], data.targets[i], data.alpha[i])))

    b = support_vectors[0][-2]  # 先初始化为第一个支持向量的目标值
    for vector in support_vectors:
        b -= vector[-1] * vector[-2] * kernel(vector[:-2], support_vectors[0][:-2])

    for i in range(len(data.data)):
        if indicator(data.data[i][0],data.data[i][1],b) > 0 and data.targets[i] == 1 :
            correct_prediction += 1
        elif indicator(data.data[i][0],data.data[i][1],b) < 0 and data.targets[i] == -1 :
            correct_prediction += 1

    print('Accuracy: ', correct_prediction/data_size)
    plot_data(data,support_vectors,b)
            