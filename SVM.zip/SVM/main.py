import numpy, random, math
from scipy.optimize import minimize
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt




bounds=0
constraints=0


def minimization(objective,TRAINING_SIZE,bounds,constraints):
    start=numpy.zeros(TRAINING_SIZE)
    ret=minimize(objective, start, bounds=bounds, constraints=constraints)
    Flag_success=ret['success']
    alpha=ret['x']
    print('alpha:', alpha)
    return alpha,Flag_success

def zerofun(alpha):
    # Implement the function zerofun
    return numpy.dot(alpha,targets)

def objective(alpha):
    P = numpy.zeros((TRAINING_SIZE, TRAINING_SIZE))
    for i in range(TRAINING_SIZE):
        for j in range(TRAINING_SIZE):
            P[i][j] = targets[i] * targets[j] * kernel(data[i], data[j])
    def f(alpha):
        sum = 0
        for i in range(TRAINING_SIZE):
            for j in range(TRAINING_SIZE):
                sum += alpha[i] * alpha[j] * P[i][j]
        return sum
    return 0.5 * f(alpha) - numpy.sum(alpha)



#kernel functions
def linear_kernel(x,y):
    return numpy.dot(x,y)
def polynomial_kernel(x,y):
    p=6
    return (numpy.dot(x,y)+1)**p
def radial_basis_kernel(x,y):
    sigma=1
    return numpy.exp(-numpy.linalg.norm(numpy.subtract(x,y))**2/2*sigma**2)

 #save the non-zero alphas with corresponding data and targets
class support_vector:
    def __init__(self,data,target,alpha):
        self.data=data
        self.target=target
        self.alpha=alpha
#generate data with random.randn:
def generate_data():
    classA=numpy.concatenate(
        (numpy.random.randn(int(TRAINING_SIZE/4),2)*0.5+[1.5,0.5],
        numpy.random.randn(int(TRAINING_SIZE/4),2)*0.5+[-1.5,0.5]))
    classB=numpy.random.randn(int(TRAINING_SIZE-len(classA)),2)*0.5+[0.0,-0.0]
    inputs=numpy.concatenate((classA,classB))
    targets=numpy.concatenate(
        (numpy.ones(classA.shape[0]),
        -numpy.ones(classB.shape[0])))
    N=inputs.shape[0]
    permute=list(range(N))
    random.shuffle(permute)
    inputs=inputs[permute,:]
    targets=targets[permute]
    return inputs,targets

def indicator(x, y):
        sum = 0
        for sv in support_vectors:
            sum += sv.alpha * sv.target * kernel(sv.data, numpy.array([x, y]))
        return sum - b

def plot_data(inputs,targets):
    plt.plot([p[0] for p in inputs[targets==1]],
            [p[1] for p in inputs[targets==1]],
            'b.')
    plt.plot([p[0] for p in inputs[targets==-1]],
            [p[1] for p in inputs[targets==-1]],
            'r.')
    xgrid=numpy.linspace(-5,5)
    ygrid=numpy.linspace(-4,4)
    grid=numpy.array([[indicator(x,y) for x in xgrid] for y in ygrid])
    plt.contour(xgrid,ygrid,grid,
                (-1.0,0.0,1.0),
                colors=('red','black','blue'),
                linewidths=(1,3,1))
    plt.axis('equal')
    plt.savefig('svmplot.pdf')
    plt.show()
def plot_data_3D(inputs, targets):

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    ax.scatter([p[0] for p in inputs[targets == 1]],
           [p[1] for p in inputs[targets == 1]],
           [indicator(p[0], p[1]) for p in inputs[targets == 1]],  # Z-axis for class A
           c='b', marker='o', label='Class A')

    ax.scatter([p[0] for p in inputs[targets == -1]],
            [p[1] for p in inputs[targets == -1]],
            [indicator(p[0], p[1]) for p in inputs[targets == -1]],  # Z-axis for class A
            c='r', marker='^', label='Class B')

    xgrid = numpy.linspace(-5, 5, 50)
    ygrid = numpy.linspace(-4, 4, 50)
    xgrid, ygrid = numpy.meshgrid(xgrid, ygrid)
    zgrid = numpy.array([[indicator(x, y) for x, y in zip(xrow, yrow)] for xrow, yrow in zip(xgrid, ygrid)])

    ax.plot_surface(xgrid, ygrid, zgrid, color='white', alpha=0.3, edgecolor='k')
    # 绘制边界（等高线）
    ax.contour(xgrid, ygrid, zgrid, levels=[-1, 0, 1], colors=['red', 'black', 'blue'], linestyles=['--', '-', '--'])

    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_zlabel('Z axis')
    plt.legend()
    plt.show()
if __name__ == '__main__':
    numpy.random.seed(100)
    TRAINING_SIZE = 40
    alpha = numpy.zeros(TRAINING_SIZE)
    C=100
    bounds = [(0, C) for _ in range(TRAINING_SIZE)]
    constraints = [{'type': 'eq', 'fun': zerofun}]
    kernel = radial_basis_kernel
    # kernel = polynomial_kernel
    
    data, targets = generate_data()
   
    alpha, found_result_flag = minimization(objective, TRAINING_SIZE, bounds, constraints)


    
    support_vectors = []
    threshold = 1e-5
    for i in range(len(alpha)):
        if alpha[i] > threshold:
            support_vectors.append(support_vector(data[i], targets[i], alpha[i]))

    b = 0
    for sv in support_vectors:
        b += sv.alpha * sv.target * kernel(sv.data, support_vectors[0].data)
    b -= support_vectors[0].target


    correct_predict = 0
    for i in range(len(data)):
        if indicator(data[i][0], data[i][1]) >1 and targets[i] == 1:
            correct_predict += 1
        elif indicator(data[i][0], data[i][1]) <-1 and targets[i] == -1:
            correct_predict += 1
    # print the correctness of the result
    correctness=correct_predict/len(data)
    print('correctness:', correctness)
    plot_data(data, targets)
    plot_data_3D(data, targets)
    print('b:', b)
  
