import pandas as pd
import numpy as np

def clean_data(file_path):
    # Read the data from the text file
    #忽略第一列
    data = pd.read_csv(file_path, header=None)
    # data = data.drop(data.columns[0], axis=1)
    # Identify columns to drop
    cols_to_drop = []
    
    # Check for constant columns and completely correlated columns
    for i in range(data.shape[1]):
        if data[i].nunique() <= 1:  # Check for constant columns
            cols_to_drop.append(i)
    
    # Check for perfect correlation
    corr_matrix = data.corr().abs()
    for i in range(len(corr_matrix.columns)):
        for j in range(i):
            if corr_matrix.iloc[i, j] == 1.0:  # Perfectly correlated columns
                cols_to_drop.append(corr_matrix.columns[i])
    
    # Drop the identified columns
    data_cleaned = data.drop(columns=cols_to_drop)
    data_cleaned.to_csv(file_path, index=False,header=False)
    print("Test data loaded", data_cleaned[0:5])
    return 

