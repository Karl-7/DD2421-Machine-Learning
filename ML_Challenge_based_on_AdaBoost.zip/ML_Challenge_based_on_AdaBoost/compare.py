def read_file(file_path):
    with open(file_path, 'r') as file:
        return [line.strip() for line in file]

def compare_files(file1, file2):
    data1 = read_file(file1)
    data2 = read_file(file2)

    differences = []
    for i, (line1, line2) in enumerate(zip(data1, data2)):
        if line1 != line2:
            differences.append((i, line1, line2))

    return differences

def main():
    file1 = 'Evaluate_result copy.txt'
    file2 = 'Evaluate_result.txt'

    differences = compare_files(file1, file2)
    if differences:
        print("Differences found:")
        for diff in differences:
            print(f"Line {diff[0]}: File1 has {diff[1]}, File2 has {diff[2]}")
            with open('differences.txt', 'w') as diff_file:
                for diff in differences:
                    diff_file.write(f"Line {diff[0]}: File1 has {diff[1]}, File2 has {diff[2]}\n")
    else:
        print("No differences found.")

if __name__ == "__main__":
    main()