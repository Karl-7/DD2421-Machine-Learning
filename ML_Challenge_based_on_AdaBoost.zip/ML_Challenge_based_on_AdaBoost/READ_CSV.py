
import pandas as pd



def read_csv(csv_file_path, txt_DATA_path, txt_LABEL_path,txt_String_LABEL_path, TrainFlag=True):
    # 读取原始数据
    data = pd.read_csv(csv_file_path)
    #关闭csv文件
    data.to_csv(txt_DATA_path, index=False)
    data = pd.read_csv(txt_DATA_path)
    # 删除第一列（datapoint序号）
    
    data = data.drop(data.columns[0], axis=1)
    # print("Data loaded", data[0:5])
    if TrainFlag:
    # 按照 first_column 的数字对数据进行排序
        first_column = data.iloc[:, 0]  # 提取第一列
        sorted_data = data.assign(label=first_column).sort_values(by='label').drop(columns='label')
        # 提取第一列（标签号）并保存到新的 txt 文件
        first_column = sorted_data.iloc[:, 0]  # 提取第一列
        # 保存为 txt 文件
        pd.Series(first_column).to_csv(txt_String_LABEL_path, index=False, header=False)  
        # 将第一列转换为分类类型，需要将所有类别转换为数值（float编码）
        categories_LABEL = ['Tesla', 'SpaceX', 'TwitterX']
        first_column = pd.Categorical(first_column, categories=categories_LABEL)
        first_column = first_column.codes   #.astype(float)
        # 保存为 txt 文件
        pd.Series(first_column).to_csv(txt_LABEL_path, index=False, header=False)  

        # # 删除第一列
        sorted_data = sorted_data.drop(sorted_data.columns[0], axis=1)
    else:
        sorted_data = data
        
    
    # 将第七列（类别列）转换为分类类型
    # sorted_data[['x7','x12']] = sorted_data[['x7','x12']].astype('category')
    # 如果需要将所有类别转换为数值（float编码）
    # sorted_data[['x7','x12']] = sorted_data[['x7','x12']].apply(lambda col: col.cat.codes)  #.astype(float)

    #手动操作，因为train和test在两次category的时候，类别结果不一样
    categories_x7 = ['AI', 'Q3', 'EBIT/Wh', 'Q2']  # 你知道的类别
    categories_x12 = ['True','False']  # 你知道的类别
    sorted_data['x7'] = pd.Categorical(sorted_data['x7'], categories=categories_x7)
    sorted_data['x12'] = pd.Categorical(sorted_data['x12'], categories=categories_x12)
    sorted_data['x7']=sorted_data['x7'].cat.codes
    sorted_data['x12']=sorted_data['x12'].cat.codes
    
    # 查看分类列的类别编码
    # print(sorted_data[['x7','x12']].apply(lambda col: col.cat.codes))
    
    # # 检查是否有缺失值
    # print(data.isnull().sum())
    

    # 将处理后的数据保存到新的 txt 文件
    sorted_data.to_csv(txt_DATA_path, index=False, header=False)
   

    print("文件已处理并保存：")
    print("1. 标签号保存为 first_column.txt")
    print("2. 转换后的数据保存为 converted_data.txt")